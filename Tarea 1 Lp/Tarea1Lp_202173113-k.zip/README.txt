Javier Figueroa Tobar
202173113-k
Para correr el programa se necesita un archivo "problemas" el cual
tiene que ser .txt
(en el tar viene un problema.txt el cual es el caso de prueba dado)